<?php
require 'vendor/autoload.php';

use Monolog\Logger;
use Monolog\Handler\StreamHandler;

class CasinoSimulation
{
    private $balance;
    private $logFile = 'logs/casino.log';
    private $logger;

    public function __construct()
    {
        // Si le solde n'est pas déjà stocké, on initialise à 100
        $this->balance = isset($_SESSION['balance']) ? $_SESSION['balance'] : 100;

        // Création du répertoire logs si il n'existe pas
        if (!file_exists('logs')) {
            mkdir('logs', 0777, true);
        }

        // Initialisation du logger avec Monolog
        $this->logger = new Logger('casino');
        $this->logger->pushHandler(new StreamHandler($this->logFile, Logger::DEBUG));

        $this->log('Démarrage de la simulation - Solde initial : ' . $this->balance);
    }

    public function spin()
    {
        $bet = 10;
        if ($this->balance < $bet) {
            $this->log('Tentative d\'appel à spin avec un solde insuffisant');
            return ['error' => 'Solde insuffisant'];
        }

        $this->balance -= $bet;
        $win = rand(0, 1) === 1; // 50% de chance de gagner

        if ($win) {
            $gain = $bet * 2;
            $this->balance += $gain;
            $this->log('Spin gagnant : +' . $gain . ' - Nouveau solde : ' . $this->balance);
            return ['result' => 'win', 'gain' => $gain, 'balance' => $this->balance];
        } else {
            $this->log('Spin perdant : -' . $bet . ' - Nouveau solde : ' . $this->balance);
            return ['result' => 'lose', 'balance' => $this->balance];
        }
    }

    public function getBalance()
    {
        $this->log('Consultation du solde : ' . $this->balance);
        return ['balance' => $this->balance];
    }

    public function deposit($amount)
    {
        if ($amount <= 0) {
            $this->log('Tentative de dépôt invalide : ' . $amount);
            return ['error' => 'Montant invalide'];
        }

        $this->balance += $amount;
        $this->log('Dépôt de ' . $amount . ' - Nouveau solde : ' . $this->balance);
        return ['message' => 'Dépôt réussi', 'balance' => $this->balance];
    }

    public function generateDailySimulation()
    {
        // Logique de simulation d'une journée
        $dailyVisitors = rand(500, 2000);
        $averageTimeSpent = mt_rand(50, 500) / 100; // Temps moyen passé en heures
        $addictionRate = mt_rand(5, 25) / 100; // Taux d'addiction entre 5% et 25%
        $estimatedAddictedPlayers = round($dailyVisitors * $addictionRate);

        // Machines à jackpot
        $machinesCount = rand(3, 10);
        $jackpotData = [];
        $totalMoneySpent = 0;
        $totalJackpots = 0;
        $jackpotOver5000 = 0;
        $revenue = 0;

        for ($i = 0; $i < $machinesCount; $i++) {
            $jackpotCount = rand(1, 2); // Nombre de jackpots gagnés sur cette machine
            $machineRevenue = 0;
            $machineJackpots = [];

            for ($j = 0; $j < $jackpotCount; $j++) {
                $jackpotAmount = rand(500, 10000); // Montant du jackpot
                if ($jackpotAmount > 5000) {
                    $jackpotOver5000++;
                }
                $machineRevenue += $jackpotAmount;
                $machineJackpots[] = $jackpotAmount;
            }

            $jackpotData[] = [
                'jackpot_count' => $jackpotCount,
                'jackpot_amounts' => $machineJackpots,
                'machine_revenue' => $machineRevenue
            ];

            // Simuler l'argent dépensé par les joueurs sur cette machine
            $totalMoneySpent += rand(5000, 20000); // Argent total dépensé sur cette machine
            $revenue += $machineRevenue; // Revenus du casino
            $totalJackpots += $jackpotCount; // Total des jackpots
        }

        // Calcul des métriques financières
        $totalMoneyWon = $revenue;
        $casinoRevenue = $totalMoneySpent - $totalMoneyWon;
        $rtp = $totalMoneyWon / $totalMoneySpent * 100;
        $arpu = $totalMoneySpent / $dailyVisitors;
        
        // Statistiques avancées
        $stats = [
            'daily_visitors' => $dailyVisitors,
            'average_time_spent_hours' => $averageTimeSpent,
            'addiction_rate' => $addictionRate,
            'estimated_addicted_players' => $estimatedAddictedPlayers,
            'machines' => $machinesCount,
            'jackpot_data' => $jackpotData,
            'total_money_spent' => $totalMoneySpent,
            'total_money_won' => $totalMoneyWon,
            'casino_revenue' => $casinoRevenue,
            'jackpot_over_5000' => $jackpotOver5000,
            'rtp' => $rtp,
            'arpu' => $arpu,
            'totalJackpots' => $totalJackpots
        ];

        // Log les statistiques
        $this->log("Simulation du jour générée :");
        $this->log("Visiteurs : $dailyVisitors, Temps moyen : $averageTimeSpent heures, Taux d'addiction : $addictionRate");
        $this->log("Machines à jackpot : $machinesCount, Total jackpots gagnés : $totalJackpots, Jackpots > 5000€ : $jackpotOver5000");
        $this->log("Total argent dépensé : $totalMoneySpent €, Total argent gagné : $totalMoneyWon €, Chiffre d'affaires : $casinoRevenue €");

        return $stats;
    }

    private function log($message)
    {
        $date = date('Y-m-d H:i:s');
        // Log Monolog
        $this->logger->info("[$date] $message");
    }

    public function persistBalance()
    {
        $_SESSION['balance'] = $this->balance;
    }
}

// Création de l'instance de la simulation
session_start();  // Assurez-vous de démarrer la session pour utiliser $_SESSION
$casino = new CasinoSimulation();

// Récupération de l'action depuis l'URL (exemple : ?action=simulate)
$action = $_POST['action'] ?? 'default';

switch ($action) {
    case 'simulate':
        // Génére une simulation de journée
        $result = $casino->generateDailySimulation();
        break;
    case 'balance':
        // Récupère le solde actuel
        $result = $casino->getBalance();
        break;
    case 'deposit':
        // Effectue un dépôt, prend le montant depuis le formulaire
        $amount = $_POST['amount'] ?? 0;
        $result = $casino->deposit((int)$amount);
        break;
    case 'spin':
        // Effectuer un spin
        $result = $casino->spin();
        break;
    default:
        // Si l'action est inconnue
        $result = ['error' => 'Action non reconnue'];
        break;
}

// Avant de finir, on persiste le solde dans la session
$casino->persistBalance();

// Afficher la réponse en JSON
header('Content-Type: application/json');
echo json_encode($result);
?>
